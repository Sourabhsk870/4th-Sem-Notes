
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class SwingDemo
{
	JFrame jfr;
	JLabel jl;
	JButton jb1,jb2;
	SwingDemo()
	{
		
		jfr=new JFrame("JFrame Demo");
		jfr.setLayout(new FlowLayout());
		jfr.setSize(250,100);
		jfr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jl=new JLabel("HJR");
		

		jb1=new JButton("OK");
		jb2=new JButton("Cancel");

		jfr.add(jb1);
		jfr.add(jb2);

		jb1.addActionListener(
		new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jl.setText("You have pressed "+ae.getActionCommand()+" Button");
			}
		}
		);

		jb2.addActionListener(
		new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jl.setText("You have pressed "+ae.getActionCommand()+" Button");
			}
		}
		);
		jfr.add(jl);
		
		jfr.setVisible(true);
	}
	public static void main(String[] args) 
	{
		SwingUtilities.invokeLater(
		new Runnable()
		{
			public void run()
			{
				new SwingDemo();
			}
		}
		);
	}
}
