import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

/*<applet code=JADemo width=250 height=250></applet>*/
public class  JADemo extends JApplet
{
	JLabel jl;
	JButton jb1,jb2;
	public void init()
	{
		setLayout(new FlowLayout());
		try
		{
			SwingUtilities.invokeAndWait(
		new Runnable()
		{
			public void run()
			{
				makeGUI();
			}
		}
		);
		}
		catch (Exception e)
		{
		}
	}

	private void makeGUI()
	{
		jl=new JLabel("HJR");
		jb1=new JButton("OK");
		jb2=new JButton("Cancel");

		add(jb1);
		add(jb2);

		jb1.addActionListener(
		new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jl.setText("You have pressed "+ae.getActionCommand()+" Button");
			}
		}
);
			jb2.addActionListener(
		new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jl.setText("You have pressed "+ae.getActionCommand()+" Button");
			}
		}
	
		);
		add(jl);
	}
}
