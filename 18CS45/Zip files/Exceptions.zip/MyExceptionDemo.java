class MyException extends Exception
{
private int detail;
	 MyException(int a)
	{
		detail=a;
	}
	public String toString()
	{
		return "MyException("+detail+")";
	}
}
class MyExceptionDemo
 
{
	static void meth(int a)throws MyException
	{
		System.out.println("Called meth("+a+")"); 
			if(a>10)
			throw new MyException(a);
		System.out.println("Normal Exit");
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		try
		{
			meth(1);
			meth(12);

			
		}
		catch (MyException e)
		{
			System.out.println("Caught: "+e);
		}
	}
}
