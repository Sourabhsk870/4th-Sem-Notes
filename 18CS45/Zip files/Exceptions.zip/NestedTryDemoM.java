class NestedTryDemoM
{
	
	static void meth(int a)
	{
		try
			{
				if(a==1) a=a/(a-a);
				if(a==2)
				{
					int c[]={1};
					c[42]=99;
				}
			}
			catch (IndexOutOfBoundsException e)
			{
				System.out.println(e);
			}
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		try
		{
			int a=args.length;
			int b=42/a;
			meth(a);
			
		}
		catch (ArithmeticException e)
		{
			System.out.println(e);
		}
	}
}
