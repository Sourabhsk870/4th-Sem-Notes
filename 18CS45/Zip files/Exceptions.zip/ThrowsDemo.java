import java.io.*;
class ThrowsDemo 
{
static void input()throws IOException
	{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Input a integer number");
try
{
	int a=Integer.parseInt(br.readLine());
System.out.println("Input numnber: "+a);

}
catch (NumberFormatException e)
{
	System.out.println("Invalid number");
}

//int a=Integer.parseInt(br.readLine());
//System.out.println("Input numnber: "+a);


	}
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");
try
{
input();	
}
catch (IOException e)
{
}



	}
}
