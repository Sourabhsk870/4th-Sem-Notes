class FinallyDemo 
{
	static void methA() throws ClassNotFoundException
	{
try
{
System.out.println("methA()");
throw new ClassNotFoundException();	
}
finally
{
	System.out.println("Inside methA's finally block");
}
		
	}
	static void methB()
	{
		try
		{
		System.out.println("methB()");
		return;
		}
		finally
		{
			System.out.println("Inside methB's finally block");
		}
	}
	static void methC()
	{
		try
		{
		System.out.println("methC()");
		
		}
		finally
		{
			System.out.println("Inside methC's finally block");
		}
	}



	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		try
		{
			methA();
		}
		catch (ClassNotFoundException e)
		{
		}
		methB();
		methC();
	}
}
