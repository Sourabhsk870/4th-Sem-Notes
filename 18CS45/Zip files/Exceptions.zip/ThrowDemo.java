class ThrowDemo 
{
	
	static void meth()
	{
		try
		{
			throw new RuntimeException("Demo");
		}
		catch (RuntimeException e)
		{
			System.out.println("Caught exception");
			throw e;
		}
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		try
		{
			meth();
		}
		catch (Exception e)
		{
			System.out.println("Recaught exception");
		}
	}
}
