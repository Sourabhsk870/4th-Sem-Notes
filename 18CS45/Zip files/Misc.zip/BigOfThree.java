import java.applet.*;
import java.awt.event.*;
import java.awt.*;
/*<applet code="BigOfThree" width="500" height="500"></applet>*/

public class BigOfThree extends Applet implements ActionListener
{
	Button b1,b2;
	TextField t1,t2,t3;
	Label l1,l2,l3;
	int res;
	public void init()
	{
		b1=new Button("Large");
		b2=new Button("Clear");

		l1=new Label("Enter first number");
		l2=new Label("Enter second number");
		l3=new Label("Enter third number");

		t1=new TextField(10);
		t2=new TextField(10);
		t3=new TextField(10);

		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(l3);
		add(t3);
		add(b1);
		add(b2);

		b1.addActionListener(this);
		b2.addActionListener(this);
	
	}
	public void actionPerformed(ActionEvent ae)
	{
		String bname=ae.getActionCommand();
		if(bname.equals("Clear"))
		{
			res=0;
			t1.setText("0");
			t2.setText("0");
			t3.setText("0");
		}
		else if(bname.equals("Large"))
		{
			try
			{
				int n1=Integer.parseInt(t1.getText());
				int n2=Integer.parseInt(t2.getText());
				int n3=Integer.parseInt(t3.getText());
				res=(n1>n2)?(n1>n3?n1:n3):(n2>n3?n2:n3);
				repaint();
				
			}
			catch (NumberFormatException nfe)
			{
				//System.out.println(nfe);
				showStatus(nfe.toString());
			}
		}
			
	}

	public void paint(Graphics g)
	{
		g.drawString("Largest: "+res,100,100);
	}
}
