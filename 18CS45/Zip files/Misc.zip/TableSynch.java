class Table
{
	synchronized void print(int n)
	{
		try
		{
			for(int i=1;i<=10;i++){
		System.out.println(n+"*"+i+"="+(n*i));
		Thread.sleep(500);
		}
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}
	}
}
class MyThread1 implements Runnable
{
	Table tbl;
	Thread t;
	int n;
	MyThread1(Table tbl,int n)
	{
		this.tbl=tbl;
		this.n=n;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		tbl.print(n);
	}
}

class MyThread2 implements Runnable
{
	Table tbl;
	Thread t;
	int n;
	MyThread2(Table tbl,int n)
	{
		this.tbl=tbl;
		this.n=n;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		tbl.print(n);
	}
}
class TableSynch 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Table tbl=new Table();
		MyThread1 ob1=new MyThread1(tbl,5);
		MyThread2 ob2=new MyThread2(tbl,10);
		try
		{
			ob1.t.join();
			ob2.t.join();
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}

	}
}
