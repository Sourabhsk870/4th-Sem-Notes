//Identify the output t of the following code.
class A 
    {
        public int i;
        protected int j;
    }    
    class B extends A 
    {
        int j;
        void display() 
        {
            super.j = 3;
            System.out.println(i + " " + j);
        }
    }    
    class Output 
    {
        public static void main(String args[])
        {
            B obj = new B();
            obj.i=1;
            obj.j=2;   
            obj.display();     
        }
   }
//a. 1,2   b. 2,1 c. 1,3 d. 3,1 
