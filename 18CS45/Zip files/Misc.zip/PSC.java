class Q
{
	int n;
	boolean valueSet=false;
	boolean valueCons=false;


	synchronized int printCb()
	{
		System.out.println("cube");
		while(!valueSet && !valueCons)
		{
			try
			{
				wait();
			}
			catch (InterruptedException ie)
			{
			System.out.println(ie);
			}
		}
		
		if(valueCons)
		{
		//System.out.println("Square of number: "+(n*n*n));
		valueSet=false;
		valueCons=false;
		
		notify();
		}
		return n*n*n;
	}
	synchronized int printSqr()
	{
				//System.out.println("Consumer1");
System.out.println("square");
		while(!valueSet)
		{
			try
			{
				wait();
			}
			catch (InterruptedException ie)
			{
				System.out.println(ie);
			}
		}
		
		if(valueSet)
		{
//		System.out.println("Square of number: "+(n*n));
		valueCons=true;
		valueSet=false;
		notify();
		}
		//notify();
		return n*n;
	}
	synchronized void put(int n)
	{
		System.out.println("Producer");
		//while( !valueCons)
		while(valueSet)
			
		{
			//System.out.println("Prod wait");
			try
			{
				wait(1000);
				//Thread.sleep(1000);
			}
			catch (InterruptedException ie)
			{
				System.out.println(ie);
			}
		}
		if(!valueSet && !valueCons){
		this.n=n;
		System.out.println("Put: "+n);
		//valueCons=false;
		valueSet=true;
		
		notify();
		}
		
	}
}
class Producer implements Runnable
{
	Q q;
	Producer(Q q)
	{
	this.q=q;
	new Thread(this,"Producer").start();
	}
	public void run()
	{
		//int i=0;
		//while(true) q.put(i++);
		for(int i=1;i<=10;i++) q.put(i);
	}
}
class Consumer1 implements Runnable
{
	Q q;
	Consumer1(Q q)
	{
	this.q=q;
	new Thread(this,"Consumer1").start();
	}
	public void run()
	{
		
		//while(true) System.out.println("SQR --> "+q. printSqr());
		for(int i=0;i<10;i++) System.out.println("SQR --> "+q. printSqr());
	}
}
class Consumer2 implements Runnable
{
	Q q;
	Consumer2(Q q)
	{
	this.q=q;
	new Thread(this,"Consumer2").start();
	}
	public void run()
	{
		
		//while(true) System.out.println("CUB--> "+q.printCb());
		for(int i=0;i<10;i++) System.out.println("CUB --> "+q. printCb());
	}
}
class PSC 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		Q q=new Q();
		Producer p=new Producer(q);
		Consumer1 c1=new Consumer1(q);
		Consumer2 c2=new Consumer2(q);
	}
}
