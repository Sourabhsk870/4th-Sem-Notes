class Thrd1 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		Thread t=Thread.currentThread();
		System.out.println("Current Thead: "+t);

		t.setName("My Thread");
		System.out.println("After name change: "+t);
		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println(i);
			Thread.sleep(1000);
			}
		}
		catch (InterruptedException ie)
		{
			System.out.println("Main Thread Interrupted");
		}

	}
}
