import java.io.*;
class Staff
{
	String id;
	String name;
	float salary;
	Staff(){}
	Staff(String id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	void display()
	{
		//System.out.println("Personal Details");
		System.out.println("Id= "+id+" Name= "+name+" Salary= "+salary);
	}
}
class Teaching extends Staff
{
	String skills;
	Teaching(){}
	Teaching(String id,String name,float salary,String skills)
	{
		super(id,name,salary);
		this.skills=skills;
	}
	void display()
	{
		
		System.out.println("Personal & Teaching Details");
		super.display();
		System.out.println("Skills= "+skills);
	}
}

class Technical extends Staff
{
	//Teaching t=new Teaching();
	String domain;
	String publications;
	Technical(){}
	Technical(String id,String name,float salary,String domain,String publications)
	{
		super(id,name,salary);
		this.domain=domain;
		this.publications=publications;
	}
	void display()
	{
		
		System.out.println("Personal & Technical Details");
		super.display();
		//t.display();
		System.out.println("Domain= "+domain+" Number of publications= "+publications);
	}
}

class Contract extends Staff
{
	float period;
	Contract(){}

	Contract(String id,String name,float salary,float period)
	{
		super(id,name,salary);
		this.period=period;
	}
	void display()
	{
		
		System.out.println("Personal & Contract Details");
		super.display();
		System.out.println("No. of Years= "+period);
	}
}
class StaffInfo
{
	public static void main(String[] args) throws IOException
	{
	Teaching tg[]=new Teaching[3];
	Technical tl[]=new Technical[3];
	Contract ct[]=new Contract[3];
	 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	  for(int i=0;i<3;i++)
	{
	  System.out.println("Enter id");
	  String id=br.readLine();
	  System.out.println("Enter name");
	  String name=br.readLine();
	  System.out.println("Enter salary");
	  float sal=Float.parseFloat(br.readLine());
	  System.out.println("Enter skills");
	  String skills=br.readLine();
	  System.out.println("Enter Domain of research");
	  String research=br.readLine();
	  System.out.println("Enter number of publications");
	  String pub=br.readLine();
	  System.out.println("Enter Contract period");
	  float period=Float.parseFloat(br.readLine());
	   tg[i]=new Teaching(id,name,sal,skills);
	   tl[i]=new Technical(id,name,sal,research,pub);
	   ct[i]=new Contract(id,name,sal,period);
 // t.display();
	}
for(int i=0;i<3;i++)
		{
					System.out.println("=================================\nStaff No. "+(i+1));
					tg[i].display();
					tl[i].display();
					ct[i].display();
					System.out.println("=================================");
		}
}
}
