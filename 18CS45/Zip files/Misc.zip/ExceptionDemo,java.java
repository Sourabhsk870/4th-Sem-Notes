class MyException extends Exception
{
	String msg;
	MyException(String str)
	{
		msg=str;
	}
	public String toString()
	{
		return "NoMatchException["+msg+"]";
	}
}

class ExceptionDemo
{
	static void compare(String str)throws MyException
	{
		System.out.println("Called compare["+str+"]");
		if(!str.equals("KSIT"))
			throw new MyException(str);
		System.out.println("Normal Exit");
	}
	public static void main(String args[])
	{
		try
		{
			
		compare("ksit");
		compare("KSIT");
		}
		catch(MyException me)
		{
			System.out.println(me);
		}
	}
}