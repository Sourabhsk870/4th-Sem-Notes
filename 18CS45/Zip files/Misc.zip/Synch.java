class Callme
{
	//synchronized 
		void call(String msg)
	{
		try
		{
			System.out.print("["+msg);
			Thread.sleep(1000);

		}
		catch (InterruptedException ie)
		{  
			System.out.println(ie);
		}
		System.out.println("]");
	}
}
class Caller implements Runnable
{
	Callme target;
	String msg;
	Thread t;
	Caller(Callme target,String msg)
	{
		this.target=target;
		this.msg=msg;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		synchronized(target){
		target.call(msg);}
	}
}
class Synch 
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");
Callme target=new Callme();
Caller ob1=new Caller(target,"Hello");
Caller ob2=new Caller(target,"Synchronization");
Caller ob3=new Caller(target,"World");

try
{
	ob1.t.join();
	ob2.t.join();
	ob3.t.join();
}
catch (InterruptedException ie)
{
	System.out.println(ie);
}

	}
}
