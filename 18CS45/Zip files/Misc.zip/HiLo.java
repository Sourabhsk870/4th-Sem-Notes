class Clicker implements Runnable
{
	Thread t;
//int n;
private volatile boolean  running=true;
 long click=0;
	Clicker(int n)
	{
		t=new Thread(this);
		t.setPriority(n);
	}

	public void start()
	{
		t.start();
	}
	public void stop()
	{
		running=false;
	}
	public void run()
	{
		while(running) click++;

	}
}
class HiLo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		//Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		Clicker lo=new Clicker(Thread.NORM_PRIORITY-2);
		//Clicker hi=new Clicker(Thread.NORM_PRIORITY+2);
		Clicker hi=new Clicker(Thread.MAX_PRIORITY);

		lo.start();
		hi.start();

		try
		{
			Thread.sleep(10000);
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}

		lo.stop();
		hi.stop();

		try
		{
			lo.t.join();
			hi.t.join();

		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}
		System.out.println("Low-priority thread: "+lo.click);
		System.out.println("High-priority thread: "+hi.click);

	}
}
