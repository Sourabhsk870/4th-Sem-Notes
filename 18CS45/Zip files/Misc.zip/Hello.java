import java.io.*;
class Hello 
{
	public static void main(String[] args) throws IOException
	{
		System.out.println("Hello World!");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter a number");
		int a=Integer.parseInt(br.readLine());
System.out.println("You entered "+a);
	}
}
