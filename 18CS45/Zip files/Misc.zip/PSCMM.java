import java.util.*;
class Print
{
	 int i;
	boolean valueSet1=false;
	boolean valueSet2=false;
	synchronized void gen(int i)
	{
	//	System.out.println("Gen");
		while(valueSet1 && valueSet2)
		{
			try
			{
				//System.out.println("Waiting");
				wait();
				
			}
			catch (InterruptedException ie)
			{
				System.out.println("THREAD1"+ie);
			}
		}
	//if(!valueSet1 && !valueSet2){
		this.i=i;
		System.out.println("n= "+i);
		
		valueSet2=true;
		valueSet1=true;
		notifyAll();
		//notify();
	//}	
	}
	synchronized void printSqr()
	{
			//	System.out.println("SQR " +valueSet1);

		while(!valueSet1)
		{
			try
			{
				//System.out.println("SQR Waiting");
				wait();
			}
			catch (InterruptedException ie)
			{
				System.out.println(ie);
			}
		}
		System.out.println(" Square of "+i+"="+(i*i));
		valueSet1=false;
		notifyAll();
		//notify();
	}

		synchronized void printCb()
	{
				//System.out.println("CUBE");

		while(!valueSet2)
		{
			try
			{
				//System.out.println("CUBE Waiting");

				wait();
			}
			catch (InterruptedException ie)
			{
				System.out.println("THREAD3 "+ie);
			}
		}
		System.out.println("Cube of "+i+"="+(i*i*i));	
		valueSet2=false;
		notifyAll();
		//notify();
	}
}
class MyThread implements Runnable
{
	String name;
	Thread t;
	 int n;
Print p;
Random r;
	MyThread(Print p)
	{
		//n=10;
		//this.name=name;
		this.p=p;
		r=new Random();
		t=new Thread(this);
		t.start();
	}

	public void run()
	{
		try
		{
			for(int i=0;i<5;i++){
			n=r.nextInt(10)+1;
			Thread.sleep(1000);
			p.gen(n);
			}
		}
		catch (InterruptedException ie)
		{
		}
	
	}
	
}


class MyThread1 implements Runnable
{
	String name;
	Thread t;
	 int n;
Print p;
	MyThread1(Print p)
	{
		//n=10;
		//this.name=name;
	this.p=p;;
		t=new Thread(this);
		t.start();
	}

	public void run()
	{
		for(int i=0;i<5;i++) p.printSqr();
	}
		
}

class MyThread2 implements Runnable
{
	String name;
	Thread t;
	// int n;
Print p;
	MyThread2(Print p)
	{
		//n=10;
		//this.name=name;
		this.p=p;
		t=new Thread(this);
		t.start();
	}

	public void run()
	{
		for(int i=0;i<5;i++) p.printCb();
	}
		
}

class PSCMM 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
Print p=new Print();
		MyThread ob1=new MyThread(p);
		MyThread1 ob2=new MyThread1(p);
		MyThread2 ob3=new MyThread2(p);
	/*	try
		{
			System.out.println("Waiting threads to finish");
			ob1.t.join();
			ob2.t.join();
			ob3.t.join();
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}*/


	}
}
