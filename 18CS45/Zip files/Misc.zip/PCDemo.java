class Q
{
	int n;
	boolean valueSet=false;
	synchronized int get()
	{
		if(!valueSet)
		{
			try
			{
				wait();
			}
			catch (InterruptedException ie)
			{
				System.out.println(ie);
			}
		}
			System.out.println("Got: "+n);
			valueSet=false;
			notify();
			
		
return n;
	}
	synchronized void put(int n)
	{
		if(valueSet)
		{
			try
			{
				wait();
			}
			catch (InterruptedException ie)
			{
				System.out.println(ie);
			}
		}
			this.n=n;
			System.out.println("Put: "+n);
			valueSet=true;
			notify();
		
	}
}

class Producer implements Runnable
{
	Q q;
Thread t;
	Producer(Q q)
	{
this.q=q;
		t=new Thread(this,"Producer");
		t.start();
	}

	public void run()
	{
		int j=0;
		for(int i=1;i<=10;i++)
			q.put(j++);
	}
}

class Consumer implements Runnable
{
	Q q;
	Thread t;
	Consumer(Q q)
	{
		this.q=q;
		t=new Thread(this,"Consumer");
		t.start();
	}
public void run()
	{
	for(int i=1;i<=10;i++)
		q.get();
	}
}
class PCDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Q q=new Q();
		Producer p=new Producer(q);
		Consumer c=new Consumer(q);
		try
		{
			p.t.join();
			c.t.join();
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}
		System.out.println("Main thread exiting");
	}
}
