import java.util.*;
class Stack
{
	int tos;
	//int size;
	int st[];
	int lb;
	int ub;
	Stack()
	{
		tos=-1;
		st=new int[10];
		//lb=0;
		//ub=9;
	}

	public void push(int ele)
	{
		if(tos>st.length-1)
		{
			System.out.println("Stack overflow");
			return;
		}
		st[++tos]=ele;
		//System.out.println(Arrays.toString(st));
		display();
		
	}
	public int pop()
	{
		if(tos<0)
		{
			System.out.println("Stack underflow");
			return -1;
		}
		tos--;
		
	//ub=tos;
	System.out.println("After pop");
	display();
	return st[tos];
	}

	public void display()
	{
		 System.out.print("Stack contents: st[ ");
		for(int i=0;i<=tos;i++)
				System.out.print(st[i]+" ");
			System.out.println("]");
	}
	
}
class StackOperation 
{
	public static void main(String[] args) 
	{
		
		Stack st=new Stack();
	int arr[]=new int[10];

	for(int i=0;i<arr.length;i++){
			st.push(i);
	}
			st.pop();
st.push(100);
st.pop();st.pop();st.pop();st.pop();st.pop();
//st.pop();st.pop();st.pop();st.pop();st.pop();

	}
}
