import java.util.*;
class Q
{
	int n;
	Random r;
	boolean valueCons=true;
	boolean valueSet=false;
	Q()
	{
		r=new Random();
	}
	synchronized void printCb()
	{
	   while(valueCons)
		{
		   try
		   {
			wait();
		   }
		   catch (InterruptedException ie)
		   {
		   }
		}
		System.out.println("Square: "+(n*n));
		valueCons=true;
		notify();
	}
	synchronized void printSqr()
	{
			while(!valueSet){
				try
				{
					wait();
				}
				catch (InterruptedException ie)
				{
				}
			}
				System.out.println("Cube : "+(n*n*n));
				valueSet=false;
				notify();
				
	}			
	synchronized void genRnd()
	{
		n=r.nextInt(10)+1;
		valueSet=true;
		//valueCons=false;
		System.out.println("RandomNum: "+n);
		try
				{
				Thread.sleep(1000);
				valueCons=false;
				}
			catch (InterruptedException ie)
				{
					System.out.println(ie);
				}
		
	}

	
}
class MyThread implements Runnable
{
	Thread t;
	String name;
	Q q;
	boolean suspendFlag=false;
	MyThread(Q q,String name)
	{
		this.q=q;
		this.name=name;
		t=new Thread(this,name);
		
		t.start();
		
	}
	public void run()
	{
		//System.out.println(t.getName());
		//this.mySuspend();
		
		
	try{
		Thread.sleep(1);
		synchronized(this)
		{
			if(t.getName().equals("One"))
		{
		//t.setPriority(10);
		for(int i=1;i<=5;i++){
			q.genRnd();
			try
				{
				t.sleep(1000);
				}
			catch (InterruptedException ie)
				{
					System.out.println(ie);
				}
		}
		}
		else if(t.getName().equals("Two"))
		{	
			//mySuspend();
			//t.setPriority(6);
		for(int i=1;i<=5;i++){
				
				q.printSqr();
			//mySuspend();
			try
				{
				t.sleep(1000);
				}
			catch (InterruptedException ie)
				{
					System.out.println(ie);
				}
		}
		}
			else if(t.getName().equals("Three"))
		{
			//mySuspend();
			for(int i=1;i<=5;i++){
			q.printCb();
			//mySuspend();
			try
				{
				t.sleep(1000);
				}
			catch (InterruptedException ie)
				{
					System.out.println(ie);
				}
			}
		}
			while(suspendFlag)
			{
				
					wait();
				
			}
		}
	}//end try
	catch(InterruptedException ie){}
	}
	
	synchronized void mySuspend()
	{
		System.out.println("Suspending thread "+name);
		suspendFlag=false;
	}
	synchronized void myResume()
	{
		System.out.println("Resuming thread "+name);
		suspendFlag=true;
		notify();
	}
}


class PSCM 
{
	public static void main(String args[])
	{
		Q q=new Q();
		MyThread ob1=new MyThread(q,"One");
		
	//ob1.t.setPriority(10);	
		
	MyThread ob2=new MyThread(q,"Two");
	//ob2.mySuspend();
	MyThread ob3=new MyThread(q,"Three");
	//ob2.mySuspend();
	//ob3.mySuspend();
	//ob3.myResume();
/*
	try
		{
			ob1.t.sleep(1000);	
		}
				catch (InterruptedException ie)
		{
		}*/
	}
}
	