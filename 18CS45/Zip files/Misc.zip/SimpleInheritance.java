class A
{
	int i,j;
	void showij()
	{
		System.out.println(" i and j is "+i+ " "+j);
	}
}

class B extends A
{
	int k;
	void showk()
	{
		System.out.println("j is "+j);
	}

	void sum()
	{
		System.out.println("i+j+k="+(i+j+k));
	}
}

class SimpleInheritance 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		A superOb=new A();
		B subOb=new B();
		superOb.i=10;
		superOb.j=20;
		System.out.println("Superob contents are");
		superOb.showij();
		System.out.println("Subob contents are");
		subOb.showij();
		subOb.showk();

	}
}
