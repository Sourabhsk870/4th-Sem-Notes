class NewThread implements Runnable
{
	Thread t;
	String name;
	NewThread(String name)
	{
		this.name=name;
		t=new Thread(this,name);
		System.out.println("Child Thread: "+t);
		t.start();
	}

	public void run()
	{
		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println(name+":"+i);
				Thread.sleep(500);
			}
		}
		catch (InterruptedException ie)
		{
			System.out.println("Child Thread Interupted");
		}
		System.out.println(name+" Exiting");
	}
}
class ThrdDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		new NewThread("one");
		new NewThread("two");
		new NewThread("three");
		try
		{
			for(int i=5;i>0;i--)
			{
			System.out.println("Main Thread: "+i);
			Thread.sleep(10000);
			}
		}
		catch (InterruptedException ie)
		{
			System.out.println("Main Thread Interupted");
		}
		System.out.println("Main Thread Exiting");
	}
}
