class ThrowDemo 
{
	static void meth()
	{
		
		try
		{
			throw new NullPointerException();
		}
		catch (NullPointerException ne)
		{
System.out.println("Caught Exception");
			throw ne;
		}
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

	//throw new NullPointerException();
		try
		{
			meth();
		}
		catch (NullPointerException e)
		{
			System.out.println("Re-Caught Exception");
		}
		
	}
}
