import java.awt.*;
import java.applet.*;
/*
<applet code="MyApplet" width="100" height="100"></applet>
*/
public class  MyApplet extends Applet
{
	public void paint(Graphics g) 
	{
		g.drawString("Welcome to Applet",20,20);
	}
}
