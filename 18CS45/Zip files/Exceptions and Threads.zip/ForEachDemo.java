class ForEachDemo 
{
	public static void main(String[] args) 
	{
		int a[]=new int[5];
		for(int i=0;i<a.length;i++) a[i]=i*2;

		for(int y:a) System.out.println(y);

		int arr[][]=new int[3][3];
for(int i=0;i<3;i++)
	for(int j=0;j<3;j++)
	arr[i][j]=i*j;
		for(int b[]:arr){
			for(int c:b) System.out.print(" "+c);
			System.out.println();
		}
	}
}
