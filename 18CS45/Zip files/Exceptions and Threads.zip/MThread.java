class NewThread implements Runnable
{
	Thread t;
	NewThread()
	{
		t=new Thread(this,"Demo Thread");
		System.out.println("Child Thread: "+t);
		t.start();
	}

	public void run()
	{
		try
		{
			for(int i=0;i<5;i++)
			{
				System.out.println("Child Thread:"+i);
				Thread.sleep(500);
			}
		}
		catch (InterruptedException ie)
		{
		}
	}
}

class  MThread
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		new NewThread();

		try
		{
			for(int i=0;i<5;i++)
			{
				System.out.println("Main Thread:"+i);
				Thread.sleep(500);
			}
		}
		catch (InterruptedException ie)
		{
		}
	}
}
