class FinallyDemo 
{
	static void procA()
	{
		System.out.println("Inside procA");
		try
		{
			throw new RuntimeException ();
		}
		finally
		{
			System.out.println("procA's finally");
		}
	}

	static void procB()
	{
				System.out.println("Inside procB");
				try
				{
					return;
				}
				finally
				{
					System.out.println("procB's finally");
				}
	}

	static void procC()
	{
		try
		{
			System.out.println("Inside procC");
		}
		finally
		{
			System.out.println("procC's finally");
		}
						
	}


	public static void main(String[] args) 
	{
	//	System.out.println("Hello World!");
	try
	{
		procA();	
	}
	catch (RuntimeException re)
	{
		System.out.println("Exception Caught");
	}
procB();
procC();
	}
}
