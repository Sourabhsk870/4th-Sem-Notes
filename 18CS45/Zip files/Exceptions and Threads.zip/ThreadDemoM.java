class Test implements Runnable
{
	Thread t;
	Test()
	{
		t=new Thread(this,"Demo1 Thread");
		//System.out.println("Child Thread"+t);
		t.start();
	}
	public void run()
	{
		//System.out.println("Running Thread "+Thread.currentThread());

		try
		{
			for(int i=1;i<=5;i++)
			{
				System.out.println(Thread.currentThread()+":"+i);
				Thread.sleep(500);
			}
		}
		catch (InterruptedException ie)
		{
		}
	}
}

class Test1 implements Runnable
{
	Thread t;
	Test1()
	{
		t=new Thread(this,"Demo2 Thread");
		//System.out.println("Child Thread"+t);
		t.start();
	}
	public void run()
	{
		//System.out.println("Running Thread "+Thread.currentThread());
		try
		{
			for(int i=1;i<=5;i++)
			{
				System.out.println(Thread.currentThread()+":"+i);
				Thread.sleep(500);
			}
		}
		catch (InterruptedException ie)
		{
		}
	}
}

class  ThreadDemoM
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");

Test o=new Test();
//Thread t=new Thread(o,"First Thread");
//t.setName("First Thread");
//t.start();

	Test1 o1=new Test1();
//Thread t1=new Thread(o1,"Second Thread");
//t1.setName("Second Thread");
//t1.start();

	}
}
