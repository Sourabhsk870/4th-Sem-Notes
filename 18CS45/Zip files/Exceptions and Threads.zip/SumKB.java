import java.io.*;
class  SumKB
{
	public static void main(String[] args) throws IOException
	{
		int a=0;
		int b=0;
		int c=0;
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter number");
		try{
		a=Integer.parseInt(br.readLine());
		}
		catch(NumberFormatException ne)
		{
			System.out.println("Exception:Invalid number "+ne);
		}
		System.out.println("Enter number");
		try{
		b=Integer.parseInt(br.readLine());
		}
		catch(NumberFormatException ne)
		{
			System.out.println("Exception:Invalid number "+ne);
		}
		c=a+b;
		System.out.println("Sum= "+c);
	}
}
