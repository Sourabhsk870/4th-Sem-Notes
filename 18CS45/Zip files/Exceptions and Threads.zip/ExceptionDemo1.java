class ExceptionDemo1 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		int a=10;
		System.out.println("Before Exception");
		try
		{
			int b=a/(a-a);
			System.out.println("This will never eecute");
		}
		catch (Exception e)
		{
			System.out.println("Exception");
		}
		System.out.println("After Exception");
	}
}
				  