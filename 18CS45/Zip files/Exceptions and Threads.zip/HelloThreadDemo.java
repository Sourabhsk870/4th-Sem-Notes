class NewThread implements Runnable
{
	Thread t;
	NewThread(String name)
	{
		t=new Thread(this,"My Group");
		t.setName(name);
		t.start();
	}
	public void run()
	{
		try
		{
			for(int i=0;i<=10;i++) System.out.println(Thread.currentThread()+":"+i);
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
		}
	}

}

class HelloThreadDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		new NewThread("First Thread");
		new NewThread("Second Thread");
	}
}
