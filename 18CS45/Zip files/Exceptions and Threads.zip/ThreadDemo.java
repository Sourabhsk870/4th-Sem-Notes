class Sum
{
	private int sum;

	public int getSum()
	{
		return sum;
	}
	public void setSum(int sum)
	{
		this.sum=sum;
	}
}

class Summation implements Runnable
{
Sum obj;
int n;
int sum;
Summation(Sum obj,int n)
	{
		this.obj=obj;
		this.n=n;
	}
public void run()
	{
		for(int i=0;i<=n;i++)
			sum+=i;
		obj.setSum(sum);
	}
}
public class ThreadDemo 
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");

Sum obj=new Sum();


Thread t=new Thread(new Summation(obj,5));
t.start();
try{
	t.join();
	System.out.println("Sum= "+obj.getSum());
}
catch(InterruptedException ie)
		{
	System.out.println("EXCEPTION : "+ie);
		}
	}
}
