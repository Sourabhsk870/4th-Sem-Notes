class MulticatchDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		try
		{
			int a=args.length;

		int b=42/a;

		int c[]={1};

		c[42]=99;
		}
		catch (ArithmeticException ae)
		{
			System.out.println(ae);
		}
		catch(ArrayIndexOutOfBoundsException ai)
		{
			System.out.println(ai);
		}
		
	}
}
