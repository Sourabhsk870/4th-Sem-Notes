class ThrowDemo1 
{
	static void meth()throws ClassNotFoundException
	{
		
		try
		{
			throw new ClassNotFoundException();
		}
		catch (ClassNotFoundException ne)
		{
System.out.println("Caught Exception");
			throw ne;
		}
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

	//throw new ClassNotFoundException();
		try
		{
			meth();
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("Re-Caught Exception");
		}
		
	}
}
