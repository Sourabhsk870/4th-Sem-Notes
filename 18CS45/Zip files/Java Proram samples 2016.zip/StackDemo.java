class ImpStack
{
	int tos;
	int st[]=new int[10];
	ImpStack()
	{
		tos=-1;
	}

	void push(int ele)
	{
		if(tos==st.length)
		{
			System.out.println("Stack overflow");
			return;
		}
		st[++tos]=ele;

	}

	int pop()
	{
		if(tos<0)
		{
			System.out.println("Stack underflow");
			return 0;
		}
		return st[tos--];
	}
}
class StackDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		ImpStack myStack1=new ImpStack();
		ImpStack myStack2=new ImpStack();

		for(int i=0;i<10;i++) myStack1.push(i);	  
		for(int i=10;i<20;i++) myStack2.push(i);

		System.out.println("MyStack1");
		for(int i=0;i<10;i++)System.out.println(myStack1.pop());
 
		
		System.out.println("MyStack2");

		for(int i=10;i<20;i++) System.out.println(myStack2.pop());


	}
}
