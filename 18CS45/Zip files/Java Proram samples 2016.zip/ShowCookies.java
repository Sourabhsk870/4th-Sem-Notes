import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class  ShowCookies extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.println("<h1>My Cookie</h1>");
		Cookie[] cookies=req.getCookies();
		if(cookies==null)
		{
			pw.println("No Cookies");
		}
		else
		{
			Cookie MyCookie;
			for(int i=0;i<cookies.length;i++)
			{
				MyCookie=cookies[i];
				pw.println(MyCookie.getName()+"=+"+MyCookie.getValue());
			}
		}
	}
}
