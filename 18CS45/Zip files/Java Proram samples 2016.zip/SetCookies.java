import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class  SetCookies extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		Cookie myCookie=new Cookie("UserID","123");
		res.addCookie(myCookie);
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.println("<h1>My Cookie</h1><p>Cookie Written</p>");
	}
}
