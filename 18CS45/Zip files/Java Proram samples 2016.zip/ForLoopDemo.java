class ForLoopDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		int a[]={1,2,3,4,5,6,7,8,9,10};
int sum=0;
		for(int i=0;i<a.length;i++) sum+=a[i]; //for(initialization;condition;iteration)
		System.out.println("Sum using simple for loop="+sum);
sum=0;
		for(int j:a) sum+=j; //for(type itr-val:collection) statement-block
		System.out.println("Sum using for-each loop="+sum);

sum=0;
		int nums[][]=new int[3][3];

		for(int i=0;i<3;i++)
			for(int j=0;j<3;j++)
				nums[i][j]=(i+1)*(j+1);
		for(int x[]:nums)
		{
			for (int y:x )
			{
				System.out.println(y);
			}
		}
	}
}
