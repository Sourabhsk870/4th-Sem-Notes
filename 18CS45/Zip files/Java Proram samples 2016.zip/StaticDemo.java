class StaticDemo 
{
		
		static int a=4;
		static int b;

	static void smeth(int x)
	{
		System.out.println("x= "+x);
		System.out.println("a= "+a);
		System.out.println("b= "+b);
	}

	static
		{
			System.out.println("Static block initialization");	
			++a;
			b=a*3;
		}
	public static void main(String[] args) 
	{
		
		smeth(42);
	}
}
