interface Addition
{
	public int add(int a,int b);
	public float add(float a,float b);
	public double add(double a,double b);
}

class Add2Nums implements Addition
{
	public int add(int a,int b)
	{
		return (a+b);
	}

	public float add(float a,float b)
	{
		return (a+b);
	}

	public double add(double a,double b)
	{
		return (a+b);
	}
}
class AddDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		Add2Nums ob1=new Add2Nums();
		//ob1.add(10,20);
		System.out.println("sum= "+ob1.add(10,20));
		System.out.println("sum= "+ob1.add(10.11f,20.22f));
		System.out.println("sum= "+ob1.add(100.0,300.0));
	}
}
