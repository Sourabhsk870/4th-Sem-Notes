class Flower
{
	String color="Undefined";
	String frag="Undefined";
	String getColor()
	{
		return color;
	}
	String getFrag()
	{
		return frag;
	}
	
}

class  YellowRose extends Flower
{
			void setColor()
			{
			color="Yellow";
			}
			void setFrag()
			{
			frag="pine";
			}
}

class  RedRose extends Flower
{
			void setColor()
			{
			color="Red";
			}
			void setFrag()
			{
			frag="Pleasant";
			}
}

public class FlowerDemo
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");
		RedRose ob=new RedRose();
		System.out.println("Rose color: "+ob.getColor());
		System.out.println("Rose fragrancs: "+ob.getFrag());
		ob.setColor();
		ob.setFrag();
		System.out.println("Rose color: "+ob.getColor());
		System.out.println("Rose fragrancs: "+ob.getFrag());
	}
}

