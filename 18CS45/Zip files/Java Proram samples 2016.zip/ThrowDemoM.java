class ThrowDemoM
{
	static void demoProc()throws ClassNotFoundException
	{
		try
		{
			throw new ClassNotFoundException("Demo");
		}
		catch (ClassNotFoundException ae)
		{
			System.out.println("Caught inside demoProc");
			throw ae;
		}
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		try
		{
			demoProc();
		}
		catch (ClassNotFoundException ae)
		{
			System.out.println("Re-Caught inside main "+ae);
		}
	}
}
