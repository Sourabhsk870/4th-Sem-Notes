class Student 
{
	String name;
	int age;
	void setAge(int a)
	{
		age=a;
	}
	void setName(String n)
	{
		name=n;
	}

	int getAge()
	{
		return age;
	}
	String getName()
	{
		return name;
	}
	public static void main(String[] args) 
	{
		Student s1=new Student();
		s1.setName("KSIT");
		s1.setAge(17);
		System.out.println("Name= "+s1.getName());
		System.out.println("Age= "+s1.getAge());
		
	}
}
