class ThrowDemo 
{
	static void demoProc()
	{
		try
		{
			throw new NullPointerException("Demo");
		}
		catch (NullPointerException ae)
		{
			System.out.println("Caught inside demoProc");
			throw ae;
		}
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		try
		{
			demoProc();
		}
		catch (NullPointerException ae)
		{
			System.out.println("Re-Caught inside main "+ae);
		}
	}
}
