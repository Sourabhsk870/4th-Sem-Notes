class Rectangle 
{
	int x;
	int y;
	int height;
	int width;
	Rectangle()
	{
		this(0,0,1,1);
	}
	Rectangle(int height,int width)
	{
		this(1,1,height,width);
	}
	Rectangle(int x,int y,int height,int width)
	{
		this.x=x;
		this.y=y;
		this.height=height;
		this.width=width;
	}
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		System.out.println("MyRectangle1");
		Rectangle myRct1=new Rectangle();
		System.out.println("X="+myRct1.x);
		System.out.println("Y="+myRct1.y);
		System.out.println("Height="+myRct1.height);
		System.out.println("Width="+myRct1.width);

		System.out.println("MyRectangle2");
		Rectangle myRct2=new Rectangle(10,10);
		System.out.println("X="+myRct2.x);
		System.out.println("Y="+myRct2.y);
		System.out.println("Height="+myRct2.height);
		System.out.println("Width="+myRct2.width);

		System.out.println("MyRectangle3");
		Rectangle myRct3=new Rectangle(10,10,10,10);
		System.out.println("X="+myRct3.x);
		System.out.println("Y="+myRct3.y);
		System.out.println("Height="+myRct3.height);
		System.out.println("Width="+myRct3.width);
	}
}
