import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*
<applet code="BigOfThree16" width="100" height="250"></applet>
*/
public class  BigOfThree16 extends Applet implements ActionListener
{
	Button b1;
	Button b2;
	TextField t1;
	TextField t2;
	TextField t3;
	Label l1;
	Label l2;
	Label l3;
	Label l4;
	String msg="";
	public void init()
	{
		b1=new Button("Ok");
		b2=new Button("Cancel");
		l1=new Label("Enter First Number");
		l2=new Label("Enter Second Number");
		l3=new Label("Enter Third Number");
		l4=new Label("");
		t1=new TextField("",10);
		t2=new TextField("",10);
		t3=new TextField("",10);

		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(l3);
		add(t3);
		add(b1);
		add(b2);
		//add(l4);

		b1.addActionListener(this);
		b2.addActionListener(this);
		//msg="Big: ";
	}
	public void actionPerformed(ActionEvent ae)
	{
		String cmd=ae.getActionCommand();
		if(cmd.equals("Cancel"))
		{
			msg="Big: ";
			t1.setText("");
			t2.setText("");
			t3.setText("");
			//l4.setText("Big: ");
			l4.setText(msg+" 0");
			repaint();
		}
		else
		{
			msg="Big: ";
			double n1=Double.parseDouble(t1.getText());
			double n2=Double.parseDouble(t2.getText());
			double n3=Double.parseDouble(t3.getText());
			double big=(n1>n2)?((n1>n3)?n1:n3):(n2>n3)?n2:n3;
			msg+=big;
			l4.setText(msg);
			repaint();
		}
		
		//repaint();
	}

	public void paint(Graphics g)
	{
		g.drawString(msg,50,230);
	}
}

