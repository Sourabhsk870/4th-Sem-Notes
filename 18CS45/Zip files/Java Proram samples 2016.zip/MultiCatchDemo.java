class  MultiCatchDemo
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		int a=10;
		int b=args.length;
		int c=0;
		int d[]={1};
		try
		{
			c=a/b;
			int z=Integer.parseInt(args[0]);
			d[99]=99;
			

		}
		
		catch (ArithmeticException ae)
		{
			System.out.println(ae);
		}
		catch(ArrayIndexOutOfBoundsException ai)
		{
			System.out.println(ai);
		}
		catch(Exception e)
		{
			System.out.println("Caught Exception");
		}
		System.out.println("After try-catch block");
	}
}
