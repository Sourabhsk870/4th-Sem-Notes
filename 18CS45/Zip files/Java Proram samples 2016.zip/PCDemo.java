class Q 
{
	int n;
	boolean valueSet=false;
	synchronized public void put(int n)
	{
		if(valueSet)
		{
			try
			{
				wait();
			}
			catch (InterruptedException ie)
			{
			}
		}
		
		this.n=n;
		System.out.println("Put: "+n);
		valueSet=true;
		notify();
	}
	synchronized public int get()
	{
		if(!valueSet)
		{
			try
			{
				wait();
			}
			catch (InterruptedException ie)
			{
			}
		}
		System.out.println("Got: "+n);
		valueSet=false;
		notify();
		return n;
	}
}
class Producer implements Runnable
{
	Thread t;
	Q q;
	Producer(Q q)
	{
		this.q=q;
		t=new Thread(this,"Producer");
		t.start();
	}
	public void run()
	{
		int i=0;
		//while(true) 
		for(int j=0;j<10;j++) q.put(i++);
	}
	
}
class Consumer implements Runnable
{
	Thread t;
	Q q;
	Consumer(Q q)
	{
		this.q=q;
		t=new Thread(this,"Consumer");
		t.start();
	}
	public void run()
	{
		//System.out.println("Consumed:"+q.get());
		//while(true)
		for(int j=0;j<10;j++) q.get();
	}
	
}
class PCDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Q q=new Q();
		Producer p=new Producer(q);
		Consumer c=new Consumer(q);
		try
		{
			p.t.join();
			c.t.join();
		}
		catch (InterruptedException ie)
		{
		}
		System.out.println("Press ctrl-c to terminate");
	}
}
