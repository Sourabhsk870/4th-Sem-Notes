import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class SetGetMyCookies extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException
	{
		String name=request.getParameter("name");
		String value=request.getParameter("psswrd");

		Cookie MyCookie=new Cookie(name,value);
		response.addCookie(MyCookie);
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<h1>Cookie Written</h1>");

		Cookie[] cookies=request.getCookies();
		if(cookies==null)
		{
			pw.println("No Cookies");
		}
		else
		{
			//Cookie AllCookies;
			for(int i=0;i<cookies.length;i++)
			{
				pw.println(cookies[i].getName()+"="+cookies[i].getValue());
			}
		}
	}
}
