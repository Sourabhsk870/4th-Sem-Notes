class A
{
	void print(){
		System.out.println("Hello from A");
		}
}
class B extends A
{
	void printMe(){
	System.out.println("Hello from B");
	}
	void print(){
		super.print();
		System.out.println("Hello from B, overriding A");
		}
}
class MethOverriding 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		B ob=new B();
		ob.print();
		ob.printMe();
		
	}
}
