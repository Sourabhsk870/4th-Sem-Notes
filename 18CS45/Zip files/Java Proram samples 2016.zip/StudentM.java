 class StudentDetails
{
	private String name;
	private int age;

	void setName(String n)
	{
		name=n;
	}
	void setAge(int a)
	{
		age=a;
	}
	int getAge()
	{
		return age;
	}
	String getName()
	{
		return name;
	}
}
public class StudentM
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		StudentDetails ob=new StudentDetails();
		//System.out.println("Name="+ob.name);
		ob.setName("KSIT");
		ob.setAge(18);
		System.out.println("Name="+ob.getName());
		System.out.println("age="+ob.getAge());

	}
}
