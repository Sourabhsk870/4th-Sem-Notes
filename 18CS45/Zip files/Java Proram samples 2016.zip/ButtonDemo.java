import java.applet.*;
import java.awt.*;
import java.awt.event.*;
/*
<applet code="ButtonDemo" width="500" height="500"></applet>
*/
public class  ButtonDemo extends Applet implements ActionListener,ComponentListener
{
	Button b1;
	String msg="";
	String msg1="";
public void init()
	{
	b1=new Button("Ok");
	add(b1);
	b1.addActionListener(this);
	b1.addComponentListener(this);
	}
	public void componentResized(ComponentEvent ce)
	{
		System.out.println("Hello "+ce.getComponent().getClass().getName()+" -----Resized");
	}
		public void componentHidden(ComponentEvent ce)
	{
		System.out.println("Hello "+ce.getComponent().getClass().getName()+" -----Hidden");
	}
		public void componentMoved(ComponentEvent ce)
	{
		System.out.println("Hello "+ce.getComponent().getClass().getName()+" -----Moved");
	}
		public void componentShown(ComponentEvent ce)
	{
		System.out.println("Hello "+ce.getComponent().getClass().getName()+" -----Shown");	
	}



	public void actionPerformed(ActionEvent ae){
		msg="";
		msg1="";
		try
		{
			msg+=ae.toString();	
			int mod=ae.getModifiers();
			msg1+=mod;
			//System.out.println(ae.cmd);
			//System.out.println(ActionEvent.ALT_MASK);
			/*System.out.println(ActionEvent.CTRL_MASK);
			System.out.println(ActionEvent.SHIFT_MASK);
			System.out.println(ActionEvent.META_MASK);
			System.out.println(ActionEvent.ACTION_PERFORMED);*/
			Object ob=ae.getSource();
		//	System.out.println(ob.toString());
		//	System.out.println(ae.paramString());
			
		
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	
		
		repaint();
	}
	public void paint(Graphics g)
	{
		g.drawString(msg,10,100);
		g.drawString(msg1,10,140);
	}
}
