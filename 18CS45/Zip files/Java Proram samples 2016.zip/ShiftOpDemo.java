class ShiftOpDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		int a=-1;

		System.out.println("Right shift: "+(a>>4));
		System.out.println("Unsigned Right shift:"+(a>>>24));
	}
}
