
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="MouseDemo" width="500" height="500"></applet>
*/
public class  MouseDemo extends Applet implements MouseListener,MouseMotionListener
{
	String msg="";
	public void init()
	{
		addMouseListener(this);
		addMouseListener(this);
	}
	public void mouseClicked(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void mouseEntered(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void mouseExited(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void mousePressed(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void mouseReleased(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void mouseDragged(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void mouseMoved(MouseEvent me)
	{
		msg="";
		msg+=me.toString();
		repaint();
	}
	public void paint(Graphics g)
	{
		g.drawString(msg,10,10);
	}
}
