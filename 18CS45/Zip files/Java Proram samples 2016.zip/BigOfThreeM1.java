import java.io.*;
class BigOfThreeM1
{
	public static void main(String[] args) throws IOException
	{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n[]=new int[3];
		
		try
		{
			for(int i=0;i<3;i++){
		System.out.println("Enter  number");
		n[i]=Integer.parseInt(br.readLine());
		}
		System.out.println("Big= "+((n[0]>n[1])?((n[0]>n[2])?n[0]:n[2]):(n[1]>n[2])?n[1]:n[2]));
		}
		catch (NumberFormatException ne)
		{
			System.out.println("Number format Exception: "+ne);
		}
		

				

		
	}
}
