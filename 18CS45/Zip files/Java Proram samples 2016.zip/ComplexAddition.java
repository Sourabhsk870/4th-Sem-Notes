class Complex
{
	double realPart;
	double imaginaryPart;
	
	Complex()
	{
	}
	Complex(double realPart,double imaginaryPart)
	{ 
	this.realPart=realPart;
	this.imaginaryPart=imaginaryPart;
	}
	void add(Complex ob2,Complex ob3)
	{
		this.realPart=ob2.realPart+ob3.realPart;
		this.imaginaryPart=ob2.imaginaryPart+ob3.imaginaryPart;
	}
	void print()
	{
		System.out.println(this.realPart+"+i"+this.imaginaryPart);
	}
}
class ComplexAddition 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Complex ob1=new Complex();
		Complex ob2=new Complex(1,1);
		Complex ob3=new Complex(2,2);
		ob1.add(ob2,ob3);
		ob1.print();

	}
}
