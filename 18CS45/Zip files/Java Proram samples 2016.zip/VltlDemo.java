class Counter 
{
	private  int  count=0; //volatile
 public void increment()//synchronized
	{
		count++;
		System.out.println("incr "+count);
			try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
		}
	

	}
 public void decrement()//synchronized
	{
		count--;
		System.out.println("dcr "+count);
			try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
		}
	
		
	}
 public int value() //synchronized
	{
		return count;
	}
}
class MyThread implements Runnable
{
	Thread t;
	Counter c;
	MyThread(Counter c)
	{
		this.c=c;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		c.increment();
		
		System.out.println(t.getName()+":"+c.value());
		c.decrement();
		System.out.println(t.getName()+":"+c.value());
	}
}

class VltlDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Counter ob1=new Counter();
		//Counter ob2=new Counter();
		new MyThread(ob1);
		new MyThread(ob1);
		
	}
}
