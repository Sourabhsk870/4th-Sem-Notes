class Box
{
	int depth;
	int width;
	int height;

	Box()
	{
		depth=0;
		height=0;
		width=0;
	}
	/*Box(int d,int h,int w)
	{
		depth=d;
		height=h;
		width=w;
	}*/

	Box(int depth,int height,int width)
	{
		this.depth=depth;
		this.height=height;
		this.width=width;
	}

	int volume()
	{
		return (depth*height*width);
	}

}
class BoxDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Box myBox1=new Box();
		Box myBox2=new Box(10,10,10);
		System.out.println("MyBox1 Dim");
		System.out.println("Depth:"+myBox1.depth);
		System.out.println("Height:"+myBox1.height);
		System.out.println("Width:"+myBox1.width);
		System.out.println("Volume:"+myBox1.volume());

		
		System.out.println("MyBox2 Dim");
		System.out.println("Depth:"+myBox2.depth);
		System.out.println("Height:"+myBox2.height);
		System.out.println("Width:"+myBox2.width);
		System.out.println("Volume:"+myBox2.volume());



	}
}
