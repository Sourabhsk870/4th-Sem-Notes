class MyThread implements Runnable
{
	Thread t;
	MyThread()
	{
		t=new Thread(this,"KSIT");
		t.start();
	}
	public void run()
	{
		//Thread t=Thread.currentThread();
		System.out.println("Current Thread : "+t);
		System.out.println("Current Thread Name : "+t.getName());
		System.out.println("Current Thread Priority : "+t.getPriority());
		try
		{
			for(int i=0;i<5;i++){
				System.out.println(t.getName()+":"+i);
			Thread.sleep(1000);
			}
		}
		catch (InterruptedException ie)
		{
		}
	}
}
public class ThreadDemo 
{
	public static void main(String[] args) 
	{
		new MyThread();
		Thread t=Thread.currentThread();
		System.out.println("Current Thread : "+t);
		System.out.println("Current Thread Name: "+t.getName());
		System.out.println("Current Thread priority: "+t.getPriority());
		try
		{
			for(int i=0;i<5;i++){
				System.out.println(t.getName()+":"+i);
			Thread.sleep(1000);
			}
		}
		catch (InterruptedException ie)
		{
		}

	}
}
