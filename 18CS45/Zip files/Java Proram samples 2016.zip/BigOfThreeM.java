import java.io.*;
class BigOfThreeM 
{
	public static void main(String[] args) throws IOException
	{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n1=0,n2=0,n3=0;
		
		System.out.println("Enter first number");
		n1=Integer.parseInt(br.readLine());

		System.out.println("Enter second number");
		n2=Integer.parseInt(br.readLine());

		System.out.println("Enter third number");
		n3=Integer.parseInt(br.readLine());

		System.out.println("Big= "+((n1>n2)?((n1>n3)?n1:n3):(n2>n3)?n2:n3));

		
	}
}
