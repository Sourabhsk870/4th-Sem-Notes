class Shared
{
	volatile int i;
	 void sharedMethod(String name)
	{
		i=10;
		System.out.println(name+":"+i);
		i=20;
		System.out.println(name+":"+i);
		i=30;
		System.out.println(name+":"+i);
	}
}
class MlthrdDemo
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Shared obj=new Shared();
		Thread t1=new Thread(){
			public void run(){System.out.println();obj.sharedMethod(this.getName());}
		};
		Thread t2=new Thread(){
			public void run(){System.out.println();obj.sharedMethod(this.getName());}
		};
		t1.start();
		t2.start();

	}
}
