class NstdTry 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		try
		{
			int a=args.length;
			System.out.println("A="+a);
			int b=100/a;
			System.out.println("b="+b);
			try
			{
				if(a==1) a=a/(a-a);
				if(a==2)
				{
					int c[]={1};
					c[100]=100;
				}
			}
			catch (ArrayIndexOutOfBoundsException ae)
			{
				System.out.println(ae);
			}
		}
		catch (ArithmeticException ae)
		{
			System.out.println(ae);
		}
	}
}
