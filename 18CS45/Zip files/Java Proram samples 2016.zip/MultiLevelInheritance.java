import java.io.*;
class Test
{
	float m1;
	float m2;
	float m3;
	Test(){}
	Test(float m1,float m2,float m3)
	{
		System.out.println("Test Called");
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
	}

	void average()
	{
		System.out.format("Subject1 Average:%.2f",((m1+m2+m3)/3.0));//("Subject1 Average="+((m1+m2+m3)/3.0));
	}
}

class Branch extends Test
{
	String bid;
	char sec;
	String usn;
	Branch(){}
	Branch(String bid,char sec,String usn,float m1,float m2,float m3)
	{
		super(m1,m2,m3);
		System.out.println("Branch Called");
		this.bid=bid;
		this.sec=sec;
		this.usn=usn;
	}
	void branchDetails()
	{
		System.out.println("Branch Id="+bid+"\nSection="+sec+"\nUSN="+usn+"\n");
	}
}


class Student extends Branch
{
	String name;
	int age;
	long phone;
	String addr;
	Student(){}
	Student(String name,int age,long phone,	String addr,String bid,char sec,String usn,float m1,float m2,float m3)
	{
		super(bid,sec,usn,m1,m2,m3);
				System.out.println("Student Called");
		this.name=name;
		this.age=age;
		this.phone=phone;
		this.addr=addr;
	}
	void studentDetails()
	{
		System.out.println("\n\nName="+name+"\nAge="+age+"\nPhone="+phone+"\nAddress="+addr+"\n");
	}
}
class MultiLevelInheritance
{
	public static void main(String[] args) 
	{
		Student s[]=new Student[2];
		for(int i=0;i<s.length-1;i++)
		{
			s[i]=new Student("HJR",99,9448612519l,"BSK","CSE",'A',"1ks13cs500",20f,25f,25f);
			s[i].studentDetails();
			s[i].branchDetails();
			s[i].average();
		}
	}
}
