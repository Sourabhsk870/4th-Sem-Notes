import java.sql.*;

public class KsitStudInfo 
{
	public static void main(String[] args) 
	{
		Connection con=null;
		ResultSet rs=null;
		Statement stmt=null;
		String URL="jdbc:odbc:KsitStudInfo";
		String username="";
		String password="";

		//load driver
		try
		{
			//Class.forName("com.ms.jdbc.odbc.JdbcOdbcDriver");
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		}
		catch (Exception e)
		{
			System.out.println("Driver Loading error "+e);
		}

		//connect to database
		try
		{
			con=DriverManager.getConnection(URL,username,password);
		}
		catch (Exception e)
		{
			System.out.println("Database connection error "+e);
		}
		//create statement
		try
		{
			stmt=con.createStatement();
		}
		catch (Exception e)
		{
			System.out.println("Statement creating error "+e);
		}
		//execute query
		try
		{
			rs=stmt.executeQuery("select * from StudInfo");	
			while(rs.next())
			{
				System.out.println("USN= "+rs.getString("susn")+" Name= "+rs.getString("sname"));
			}
		}
		catch (Exception e)
		{
			System.out.println("Execution error "+e);
		}

		//close database connection
		try
		{
			con.close();
		}
		catch (Exception e)
		{
			System.out.println("Couldn't close database "+e);
		}
		
	}
}
