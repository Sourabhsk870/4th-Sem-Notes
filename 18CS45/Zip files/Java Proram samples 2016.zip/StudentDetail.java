class StudentDetail 
{
	String name;
	int age;
	StudentDetail()
	{
		name="";
		age=0;
	}
	StudentDetail(String n,int a)
	{
		name=n;
		age=a;
	}
	void setName(String n)
	{
		name=n;
	}
	void setAge(int a)
	{
		age=a;
	}
	String getName()
	{
		return name;
	}
	int getAge()
	{
		return age;
	}
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");
StudentDetail ob=new StudentDetail();
System.out.println("Name= "+ob.getName());
System.out.println("Name= "+ob.getAge());

ob.setName("KSIT");
ob.setAge(18);
System.out.println("Name= "+ob.getName());
System.out.println("Name= "+ob.getAge());

StudentDetail ob1=new StudentDetail("ABC",99);
System.out.println("Name= "+ob1.getName());
System.out.println("Name= "+ob1.getAge());


	}
}
