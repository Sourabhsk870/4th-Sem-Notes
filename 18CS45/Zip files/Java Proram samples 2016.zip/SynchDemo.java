class CallMe
{
 void call(String msg) //	synchronized
	{
		System.out.print("["+msg);
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
		}
		System.out.println("]");
	}
}
class Caller implements Runnable
{
	Thread t;
	CallMe c;
	String msg;
	Caller(CallMe c,String msg)
	{
		this.c=c;
		this.msg=msg;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		//c.call(msg);
		synchronized(c){c.call(msg);}
	}
}
class SynchDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		CallMe ob=new CallMe();
		new Caller(ob,"Hello");
		new Caller(ob,"Welcome");
		new Caller(ob,"HJR");
	}
}
