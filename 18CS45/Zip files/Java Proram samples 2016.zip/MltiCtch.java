class  MltiCtch
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		try
		{
			int a=args.length;
			System.out.println("a="+a);
			int b=100/a;
			int c[]={1};
			c[100]=100;
		}
		catch (ArithmeticException ae)
		{
			System.out.println(ae);
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println(ae);
		}
	}
}
