import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="AppletDemo" width="300" height="300"></applet>
*/
public class AppletDemo extends Applet implements ActionListener
{
	Button b1;
	Button b2;
	public void init()
	{
		setBackground(Color.blue);
		setForeground(Color.magenta);
		b1=new Button("Green");
		b2=new Button("Red");
		add(b1);
		add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
	}
public void actionPerformed(ActionEvent ae)
	{
	String clr=ae.getActionCommand();
	if(clr.equals("Green")) setBackground(new Color(0,255,0));
	else if(clr.equals("Red")) setBackground(new Color(255,0,0));
	repaint();
	}
	public void paint(Graphics g)
	{
		g.drawString("Hello! Applet",10,10);
	}
}
