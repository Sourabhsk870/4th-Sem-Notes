public class LocalClassDemo 
{
	static String regulaExpression="[^0-9]"; 

	public static void validatePhoneNumber(String phoneNumber1,String phoneNumber2)
	{
		final int numberLength=10;
		class PhoneNumber
		{
			String formattedPhoneNumber=null;
			PhoneNumber(String phoneNumber)
			{
				String currentNumber=phoneNumber.replaceAll(regulaExpression,"");
				if (currentNumber.length()==numberLength)
				{
					formattedPhoneNumber=currentNumber;
				}
				else 
				{
					formattedPhoneNumber=null;
				}
			}//end con
			public String getNumber()
			{
				return formattedPhoneNumber;
			}//end gN
			public void printOriginalNumber()
			{
				System.out.println("Original Numbers are "+phoneNumber1+" and "+phoneNumber2);
			}
		}//end inner class
		PhoneNumber mynumber1=new PhoneNumber(phoneNumber1);
		PhoneNumber mynumber2=new PhoneNumber(phoneNumber2);
		mynumber1.printOriginalNumber();

		if (mynumber1.getNumber()==null)
		System.out.println("First number is invalid");
		else
		System.out.println("First number is "+mynumber1.getNumber());

		if (mynumber2.getNumber()==null)
		System.out.println("Second number is invalid");
		else
		System.out.println("Second number is "+mynumber2.getNumber());
	}//end fun
	public static void main(String... args) 
	{
		//System.out.println("Hello World!");
		validatePhoneNumber("944-86-12519","2672-1307");
	}
}
