class Callme
{
	synchronized void call(String msg)
	{
		System.out.print("["+msg);
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
		}
		System.out.println("]");
	}
}
class Caller implements Runnable
{
	String msg;
	Thread t;
	Callme c;
	Caller(String msg,Callme obj)
	{
		this.msg=msg;
		c=obj;
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		c.call(msg);
	}
}
class SyncDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		Callme c=new Callme();
		new Caller("Hello",c);
		new Caller("Synchronization",c);
		new Caller("World",c);
	}
}
