class Callme
{
	
	 void call(String msg)
	{
		System.out.print("["+msg);
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
		}
		System.out.println("]");
	}
}

class Caller implements Runnable
{
	Callme obj;
	Thread t;
	String msg;
	Caller(Callme obj,String msg)
	{
		this.msg=msg;
		this.obj=obj;
		t=new Thread(this);
		t.start();
	}

public void run()
{
	synchronized(obj){
	obj.call(msg);
	}
}
}
class  SyncDemo2
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");

Callme obj=new Callme();
new Caller(obj,"Hello");
new Caller(obj,"synchronization");
new Caller(obj,"World");
	}
}
