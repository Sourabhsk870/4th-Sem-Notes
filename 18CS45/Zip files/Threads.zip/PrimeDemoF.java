class PrimeF implements Runnable
{
Thread t;
String name;
static char a[]=new char[100];
int nt[]=new int[2];


	PrimeF(String name)
	{
		this.name=name;
		for(int i=0;i<a.length;i++)
				a[i]='r';
		a[0]='d';
		a[1]='d';

		t=new Thread(this,name);
//System.out.println(t);
		if(t.getName().equals("First"))
		{
			//System.out.println(t);
			nt[0]=2;
			nt[1]=5;
			t.start();
		}
		if(t.getName().equals("Second"))
		{
			//System.out.println(t);
			nt[0]=3;
			nt[1]=7;
			t.start();
		}

	}
	public void run()
	{
			
			int arr_len=nt.length;
			int count=0;

			while(arr_len>0)
		{
				//System.out.println(t);
				int i=nt[count];
				//System.out.println(arr_len+" "+i);
				if(a[i]=='r')
			{
					for(int j=2;j*i<a.length;j++)
				{
						a[j*i]='d';
						System.out.println(i+":a["+(j*i)+"]="+a[j*i]);
				}
			}
			arr_len--;
			count++;

		}
	}
}
class PrimeDemoF 
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");

PrimeF t1=new PrimeF("First");
PrimeF t2=new PrimeF("Second");

try
{
	t1.t.join();
	t2.t.join();
}
catch (InterruptedException ie)
{
}
System.out.println("The Prime numbers b/w 1-100:");
for(int i=0;i<PrimeF.a.length;i++)
	if(PrimeF.a[i]=='r')
	System.out.print(i+" ");

	}
}
