
class PrimeM implements Runnable
{
	Thread t;
	String name;
	static char a[]=new char[100];

	PrimeM(String name)
	{
		this.name=name;

		for(int i=0;i<a.length;i++) a[i]='r';
		a[0]='d';
		a[1]='d';

		t=new Thread(this,name);
		t.start();
	}
	
	public void run()
	{
		if(t.getName().equals("first"))
		{
			for(int i=2;i<=3;i++)
			{
				if(a[i]=='r')
				{
					for(int j=i;j*i<a.length;j++)
					{
						a[j*i]='d';
						System.out.println(Thread.currentThread()+"a["+(j*i)+"]--->"+a[j*i]);
					}
				}
			}
		}
	

	if(t.getName().equals("second"))
		{
			for(int i=5;i<=7;i+=2)
			{
				if(a[i]=='r')
				{
					for(int j=i;j*i<a.length;j++)
					{
						a[j*i]='d';
						System.out.println(Thread.currentThread()+"a["+(j*i)+"]--->"+a[j*i]);
					}
				}
			}
		}
	}
}
class PrimeDemoM 

{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		PrimeM ob1=new PrimeM("first");
		PrimeM ob2=new PrimeM("second");

		try
		{
			System.out.println("Waiting for threads to complete");
			ob1.t.join();
			ob2.t.join();
		}
		catch (InterruptedException e)
		{
		}
for(int i=0;i<PrimeM.a.length;i++)
	if(PrimeM.a[i]=='r')
	System.out.print(i+" ");
	}
}
