class CurrentThread  
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		Thread t=Thread.currentThread();
		System.out.println("Current Thread:"+t);
		System.out.println("Default priority"+t.getPriority());
		t.setName("HJR");
		t.setPriority(1);
		System.out.println("Reassigned priority:"+t.getPriority());
		System.out.println("New name:"+t.getName()+t);

		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println(i);
				Thread.sleep(1000);
			}
		}
		catch (InterruptedException e)
		{
		}

	}
}
