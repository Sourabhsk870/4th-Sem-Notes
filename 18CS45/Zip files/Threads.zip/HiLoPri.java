
class Clicker implements Runnable
{
	Thread t;

	private volatile boolean running=true;

	long click=0;

	Clicker(int p)
	{
		t=new Thread(this);
		t.setPriority(p);
	}
	public void start()
	{
		t.start();
	}

	public void run()
	{
		while(running) click++;
	}
	public void stop()
	{
		running=false;
	}

}
class HiLoPri 
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");
Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
Clicker lo=new Clicker(Thread.NORM_PRIORITY-2);
Clicker hi=new Clicker(Thread.NORM_PRIORITY+2);

lo.start();
hi.start();
try
{
	Thread.sleep(100);
}
catch (InterruptedException ie)
{
}

lo.stop();
hi.stop();
try
{
	lo.t.join();
	hi.t.join();
}
catch (InterruptedException ie)
{
}
System.out.println("Low priority thread:"+lo.click);
System.out.println("High priority thread:"+hi.click);
	}
}
