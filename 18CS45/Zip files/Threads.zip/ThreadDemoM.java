class NewThreadM extends Thread
{
	NewThreadM()
	{
		super("Demo thread");
		System.out.println("child thread"+this);
		start();
	}
	public void run()
	{
	}
}
class ThreadDemoM
	{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		new NewThreadM();
	}
}
