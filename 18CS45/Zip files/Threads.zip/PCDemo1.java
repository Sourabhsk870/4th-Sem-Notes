
class Q
{
	private int n;
	boolean setFlag=false;
	synchronized void put(int n)
	{
		try
		{
			while(setFlag)
				wait();
		}
		catch (InterruptedException ie)
		{
		}
		this.n=n;
		System.out.println("put:"+n);
		setFlag=true;
		notify();
	}
	synchronized int get()
	{
try
{
	while(!setFlag)
		wait();
}
catch (InterruptedException ie)
{
}
		System.out.println("got:"+n);
		setFlag=false;
		notify();
		return n;
	}
}

class Producer implements Runnable
{
	Thread t;
	Q q;
	Producer(Q q)
	{
		this.q=q;
		t=new Thread(this,"Producer");
		t.start();
	}
	public void run()
	{
		int n=0;
		while(true)
			q.put(n++);
	}
}
class Consumer implements Runnable
{
	Thread t;
	Q q;
	Consumer(Q q)
	{
		this.q=q;
		t=new Thread(this,"Consumer");
		t.start();
	}
	public void run()
	{
		int n=0;
		while(true)
			q.get();
	}
}

class PCDemo1 
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");

Q q=new Q();
Producer p=new Producer(q);
Consumer c=new Consumer(q);
System.out.println("Press ctrl-c to quit");
	}
}
