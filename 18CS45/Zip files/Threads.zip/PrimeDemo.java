class Prime implements Runnable 
{
	static char a[]=new char[100];
	String name;
	Thread t;
	
	Prime(String name){
	this.name=name;
	for(int i=0;i<a.length;i++) a[i]='r';
	a[0]='d';
	a[1]='d';
	}
	public void start()
	{
		t=new Thread(this,name);
		t.start();
	}
	public void run()
	{
		//System.out.println(Thread.currentThread());

		if(t.getName().equals("one"))
		{
			
			for(int i=2;i<=3;i++)
			{
						if(a[i]=='r')
						{
							for(int j=i;j*i<a.length;j++)
							{
								
								a[j*i]='d';
								System.out.println(Thread.currentThread()+"a["+(j*i)+"]:"+a[j*i]);
							}
						}
			}
		} 
		if(t.getName().equals("two"))
		{
			
			for(int i=5;i<=7;i+=2)
			{
						if(a[i]=='r')
						{
							for(int j=i;j*i<a.length;j++)
							{
								
								a[j*i]='d';
								System.out.println(Thread.currentThread()+"a["+(j*i)+"]:"+a[j*i]);
							}
						}
			}

		}
		
	}
}

class PrimeDemo
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
//		new Prime("one").start();
//		new Prime("two").start();
Prime t1=new Prime("one");
Prime t2=new Prime("two");

t1.start();
t2.start();

try
{
	
	t1.t.join();
	t2.t.join();
	System.out.println("Waiting finished");
}
catch (InterruptedException ie)
{

}
for(int i=0;i<Prime.a.length;i++)
	if(Prime.a[i]=='r')
	  System.out.print(i+"  ");
}
}
