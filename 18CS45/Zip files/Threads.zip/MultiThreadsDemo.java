
class MultiThreads implements Runnable
{
	Thread t;
	String name;
	MultiThreads(String name)
	{
		this.name=name;
		t=new Thread(this,name);
		System.out.println("New child thread:"+t);
		t.start();
	}
	public void run()
	{
		
	}
}
class MultiThreadsDemo 
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");

		new MultiThreads("one");
				new MultiThreads("two");
						new MultiThreads("three");
	}
}
