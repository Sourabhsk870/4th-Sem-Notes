class A
{
	synchronized void foo(B b)
	{
		String name=Thread.currentThread().getName();
		System.out.println(name+" entered A.foo");
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}
		System.out.println(name+" trying to call B.last");
		b.last();
	}
	synchronized void last()
	{
		System.out.println("Inside A.last");
	}
}

class B
{
	synchronized void bar(A a)
	{
		String name=Thread.currentThread().getName();
		System.out.println(name+" entered B.bar");
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException ie)
		{
			System.out.println(ie);
		}
		System.out.println(name+" trying to call A.last");
		a.last();
	}
	synchronized void last()
	{
		System.out.println("Inside B.last");
	}
}

class DLDemo implements Runnable
{
Thread t;
A a;
B b;
DLDemo()
	{
	a=new A();
	b=new B();
	Thread.currentThread().setName("Main Thread");
	t=new Thread(this,"Racing Thread");
	t.start();
	a.foo(b);
	System.out.println("Back in Main Thread");
	}
	public void run()
	{
		b.bar(a);
		System.out.println("Back in other thread");
	}
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!");
new DLDemo();
	}
}
