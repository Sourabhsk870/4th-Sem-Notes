import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*
<applet code=EventDemo width=150 height=300></applet>
*/
public class EventDemo extends Applet  implements ActionListener
{
	Label l1;
	Label l2;
	Label l3;
	Label l4;
	Button b1;
	Button b2;
	TextField t1;
	TextField t2;
	TextField t3;
	TextField t4;
	String res="";
	int  big;

	public void init()
	{
		l1=new Label("Enter 1st number");
		l2=new Label("Enter 2nd number");
		l3=new Label("Enter 3rd number");
		l4=new Label("Biggest of three numbers:");
		t1=new TextField(5);
		t2=new TextField(5);
		t3=new TextField(5);
		t4=new TextField("0",5);
		b1=new Button("OK");
		b2=new Button("Cancel");

		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(l3);
		add(t3);
		add(b1);
		add(b2);
		add(l4);
		add(t4);

		b1.addActionListener(this);
		b2.addActionListener(this);

	}

	public void actionPerformed(ActionEvent ae)
	{
		String str=ae.getActionCommand();
		if(str.equals("OK"))
		{
			try
			{
				int first=Integer.parseInt(t1.getText());
				int second=Integer.parseInt(t2.getText());
				int third=Integer.parseInt(t3.getText());
				big=(first>second)?((first>third?first:third)):(second>third)?second:third;
				t4.setText(""+big);
				
			}
			catch (NumberFormatException nfe)
			{
				//System.out.println("Number format exception: required integer number");
				showStatus("Number format exception: required integer number");
			}
		}
		else if(str.equals("Cancel"))
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
		}
		//repaint();

	}
	public void paint(Graphics g)
	{
		
	}
}
