import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
/*
<applet code=Resume3 width=150 height=500></applet>
*/
public class Resume3 extends JApplet implements ItemListener,ListSelectionListener 
{
JLabel j1,j2,j3,j4,j5,j6,j7,j8,j9,j10;
JButton jb1,jb2;//ActionEvent
JComboBox jc1,jc2,jc3;//ActionEvent
JTextField jt;//ActionEvent
JRadioButton jr1,jr2;//ActionEvent
JCheckBox jcb1,jcb2,jcb3,jcb4;//ItemEvent
JList jlst;//ListSelectionEvent

String day[]={"1","2","3","4","5","6","7","8","9"};
String mon[]={"Sep","Oct"};
String year[]={"1972","1974"};
String pl[]={"Java","C","C++"};

public void init()
	{
		try
		{
			SwingUtilities.invokeAndWait(
		new Runnable()
		{
			public void run()
			{
				makeGUI();
			}
		}
		);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
	private void makeGUI()
	{
		setLayout(new FlowLayout());
		j10=new JLabel("Select Controls");
		j1=new JLabel("Resume");
		add(j1);
		j2=new JLabel("Personal Information");
		j3=new JLabel("Name");
		jt=new JTextField("HJR",25);
		add(j2);
		add(j3);
		add(jt);
		j4=new JLabel("DOB: Day");
		jc1=new JComboBox(day);
		j5=new JLabel("Mon");
		jc2=new JComboBox(mon);
		j6=new JLabel("Year");
		jc3=new JComboBox(year);
		add(j4);
		add(jc1);
		add(j5);
		add(jc2);
		add(j6);
		add(jc3);

		j7=new JLabel("Gender");
		jr1=new JRadioButton("Male",true);
		jr2=new JRadioButton("Female");

		add(j7);
		add(jr1);
		add(jr2);

		ButtonGroup bg=new ButtonGroup();
		bg.add(jr1);
		bg.add(jr2);

		j8=new JLabel("Educational Qualification");
		jcb1=new JCheckBox("SSLC");
		jcb2=new JCheckBox("PUC");
		jcb3=new JCheckBox("BE");
		jcb4=new JCheckBox("PhD");

		add(j8);
		add(jcb1);
		add(jcb2);
		add(jcb3);
		add(jcb4);
		jcb1.addItemListener(this);
		j9=new JLabel("Programming Language Knowledge");
		jlst=new JList(pl);

		add(j9);
		add(jlst);
		jlst.addListSelectionListener(this);

jb1=new JButton("OK");
jb2=new JButton("Cancel");
add(jb1);
add(jb2);
jb1.addActionListener(
new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				j10.setText("Pressed "+ae.getActionCommand()+" Button");
			}
		}
);

jb2.addActionListener(
new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				j10.setText("Pressed "+ae.getActionCommand()+" Button");
			}
		}
);

		add(j10);

	}

	public void itemStateChanged(ItemEvent ie)
	{
		JCheckBox jcb=(JCheckBox)ie.getItem();
		if(jcb.isSelected())
			j10.setText(jcb.getText()+" is selected");
		else
			j10.setText(jcb.getText()+" is cleared");
	}

	public void valueChanged(ListSelectionEvent lse)
	{
		int idx=jlst.getSelectedIndex();
		if(idx!=-1)
			j10.setText("Programming Language: "+pl[idx]);
			else
				j10.setText("Select city");


	}
}
