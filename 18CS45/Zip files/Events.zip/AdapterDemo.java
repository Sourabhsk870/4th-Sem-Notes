import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code=AdapterDemo width=500 height=500></applet>
*/
public class  AdapterDemo extends Applet
{
public void init()
	{
	addMouseListener(new MyMouseAdapter(this));
	addMouseMotionListener(new MyMouseMotionAdapter(this));
	}
}

class MyMouseAdapter extends MouseAdapter
{
	AdapterDemo ad;
	public MyMouseAdapter(AdapterDemo ad)
	{
		this.ad=ad;
	}
	public void mouseClicked(MouseEvent me)
	{
		ad.showStatus("Mouse clicked");
	}
}

class MyMouseMotionAdapter extends MouseMotionAdapter
{
	AdapterDemo ad;
	public MyMouseMotionAdapter(AdapterDemo ad)
	{
		this.ad=ad;
	}

	public void mouseDragged(MouseEvent me)
	{
		ad.showStatus("Mouse Dragged");
	}
}