import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code=AdapterDemoM width=500 height=500></applet>
*/
public class  AdapterDemoM extends Applet
{
public void init()
	{
	addMouseListener(new MyMouseAdapter());
	 //addMouseMotionListener(new MyMouseMotionAdapter());
	}

	class MyMouseAdapter extends MouseAdapter
	{
		public void mouseClicked(MouseEvent me)
		{
			showStatus("Mouse Clicked");
		}
	}
}
/*
class MyMouseAdapter extends MouseAdapter
{
	AdapterDemo ad;
	public MyMouseAdapter(AdapterDemoM ad)
	{
		this.ad=ad;
	}
	public void mouseClicked(MouseEvent me)
	{
		ad.showStatus("Mouse clicked");
	}
}

class MyMouseMotionAdapter extends MouseMotionAdapter
{
	AdapterDemo ad;
	public MyMouseMotionAdapter(AdapterDemoM ad)
	{
		this.ad=ad;
	}

	public void mouseDragged(MouseEvent me)
	{
		ad.showStatus("Mouse Dragged");
	}
}

*/