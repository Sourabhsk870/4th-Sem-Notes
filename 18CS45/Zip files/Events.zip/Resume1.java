import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
/*
<applet code=Resume1 width=150 height=800></applet>
*/
public class Resume1 extends JApplet implements ActionListener,ItemListener,ListSelectionListener
{

	JLabel jl1,jl2,jl3,jl4,jl5,jl6,jl7,jl8,jl9,jlres,jlres1;
	JButton jb1,jb2;//actionlistener
	JRadioButton jrb1,jrb2;//actionlistener
	JTextField jtf1;
	JComboBox jcb1,jcb2,jcb3,jcb4;//actionlistener
	JList jlst1;//listselectionlistener
JCheckBox jc1,jc2,jc3,jc4;//itemlistener
String dy[]={"1","2","3","4","5","6","7","8","9","10"};
String mn[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
String yr[]={"1970","1971","1972","1973","1974","1975","1976","1977","1978","1979","1980"};
String pl[]={"Java","C","C++"};
	public void init()
	{
		try
		{
			SwingUtilities.invokeAndWait(
				new Runnable()
			{
					public void run()
				{
				makeGUI();
				}
			}
		);
		}
		catch (Exception ie)
		{
			System.out.println(ie);
		}

	}
	private void makeGUI()
	{
setLayout(new FlowLayout());
		jl1=new JLabel("RESUME");
		add(jl1);
		jl2=new JLabel("Personal Information");
		add(jl2);
		jl3=new JLabel("Name :");
		jtf1=new JTextField(20);
		add(jl3);
		add(jtf1);
		jl4=new JLabel("DOB : Day");
		jl5=new JLabel("Mon");
		jl6=new JLabel("Year");
		jcb1=new JComboBox(dy);
		jcb2=new JComboBox(mn);
		jcb3=new JComboBox(yr);
		jcb4=new JComboBox();

		add(jl4);
		add(jcb1);
		add(jl5);
		add(jcb2);
		add(jl6);
		add(jcb3);
		
		jcb1.addActionListener(this);
		jcb2.addActionListener(this);
		jcb3.addActionListener(this);
		jcb4.addActionListener(this);

jrb1=new JRadioButton("Male");
jrb2=new JRadioButton("Female");
jl7=new JLabel("Gender");
add(jl7);
add(jrb1);
add(jrb2);
jrb1.addActionListener(this);
jrb2.addActionListener(this);
		jl8=new JLabel("Educational Qualification");
		jc1=new JCheckBox("SSLC");
		jc2=new JCheckBox("PUC");
		jc3=new JCheckBox("BE");
		jc4=new JCheckBox("PhD");
		add(jl8);
		add(jc1);
		add(jc2);
		add(jc3);
		add(jc4);
jc1.addItemListener(this);
jc2.addItemListener(this);
jc3.addItemListener(this);
jc4.addItemListener(this);
	jl9=new JLabel("Programming Language");
jlst1=new JList(pl);
	add(jl9);
	add(jlst1);
jlst1.addListSelectionListener(this);
jlst1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	jb1=new JButton("OK");
	jb2=new JButton("Cancel");
	add(jb1);
	add(jb2);

	jb1.addActionListener(this);
	jb2.addActionListener(this);

	jlres=new JLabel();
	add(jlres);
    jlres1=new JLabel();
	add(jlres1);
	}
	public void actionPerformed(ActionEvent ae)
	{
		jlres.setText("");
		jlres.setText("You selected "+ae.getActionCommand());
		String s=(String)jcb1.getSelectedItem();
		jlres1.setText("You selected "+s);
	}

	public void itemStateChanged(ItemEvent ie)
	{
		
		JCheckBox cb=(JCheckBox)ie.getItem();
		if(cb.isSelected())
			jlres.setText(cb.getText()+ " is selected");
		else
			jlres.setText(cb.getText()+" is cleared");
	}

	public void valueChanged(ListSelectionEvent lse)
	{
		/*int indx=jlst1.getSelectedIndex();
		if(indx!=-1)
			jlres.setText("current selection "+pl[indx]);
		else
			jlres.setText("select PL");*/

			String s=(String)jlst1.getSelectedValue();
			jlres.setText("current selection "+s);
	}
}
