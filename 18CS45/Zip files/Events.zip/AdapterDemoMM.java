import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code=AdapterDemoMM width=500 height=500></applet>
*/
public class  AdapterDemoMM extends Applet
{
public void init()
	{
	addMouseListener(new MouseAdapter()
		{
		public void mouseClicked(MouseEvent me)
		{
			showStatus("Mouse Clicked");
		}
		}
	);
	
	}


}
