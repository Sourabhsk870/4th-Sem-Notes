import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*
<applet code=Resume width=300 height=200></applet>
*/
public class  Resume extends Applet implements ActionListener,ItemListener
{
	Label l1;
	Label l2;
	Label l3;
	Label l4;
	Label l5;
	Label l6;
	Label l7;
	Label l8;

	TextField t1;

	Choice d;
	Choice m;
	Choice y;

	Checkbox cb1;
	Checkbox cb2;
	Checkbox cb3;
	Checkbox cb4;

	CheckboxGroup cbg;
	Checkbox cb5;
	Checkbox cb6;

Button b1;
Button b2;

ComboBox
//String dd[]={"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
String dd="1";//,"2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
	public void init()
	{
		Panel p1=new Panel();
		//setLayout(new BorderLayout());
		l1=new Label("RESUME");
//		add(l1,BorderLayout.NORTH);
		p1.add(l1);
		Panel p2=new Panel();
		l2=new Label("Name :");
		t1=new TextField("HJR",25);
		//add(t1,BorderLayout.CENTER);
		//add(l2,BorderLayout.WEST);
		p2.add(l2);
		p2.add(t1);
		//l3=new Label("DOB");
		//add(l3,BorderLayout.WEST);

		Panel p3=new Panel();

		l3=new Label("DOB");
		//d=new Choice();
		d.add(dd);
		p3.add(l3);
		p3.add(d);
		
add(p1);
add(p2);
add(p3);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		//ae.getActionCommand();
	}

	public void itemStateChanged(ItemEvent ie)
	{
		//ie.getItemStateChanged();
	}
}
