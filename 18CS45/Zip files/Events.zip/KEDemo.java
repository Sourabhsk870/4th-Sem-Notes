import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code=KEDemo width=500 height=500></applet>
*/
public class  KEDemo extends Applet implements KeyListener
{
	String msg="";
	int x=10,y=20;
	public void init()
	{
		addKeyListener(this);
	}
	public void keyPressed(KeyEvent ke)
	{
		showStatus("Key down");
		int key=ke.getKeyCode();

		switch(key)
		{
			case KeyEvent.VK_F1:
				msg+="<F1>";
			repaint();
				break;

				case KeyEvent.VK_F2:
				msg+="<F2>";
			repaint();
				break;
		case KeyEvent.VK_PAGE_DOWN:
			msg+="<PAGE DOWN>";
			repaint();
				break;

				case KeyEvent.VK_RIGHT:
					msg+="<RIGHT ARROW>";
			repaint();
				break;

		}
	}

	public void keyReleased(KeyEvent ke)
	{
		showStatus("Key Up");
	}

	public void keyTyped(KeyEvent ke)
	{
		msg+=ke.getKeyChar();
		repaint();
	}
	public void paint(Graphics g)
	{
		g.drawString(msg,x,y);
	}
}
