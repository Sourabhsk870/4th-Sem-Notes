import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
/*
<applet code=Resume2 width=150 height=480></applet>
*/

public class Resume2 extends JApplet implements ItemListener
{
	JLabel jl1,jl2,jl3,jl4,jl5,jl6,jl7,jl8,jl9,jl10;
	JButton jb1,jb2; //ActionListener
	JTextField jtf1;//ActionListener
	JComboBox jcb1,jcb2,jcb3;//ActionListener
	JRadioButton jrb1,jrb2;//ActionListener
	JCheckBox jc1,jc2,jc3,jc4;//ItemListener
	JList jlst1;//ListSelectionListener
	String day[]={"1","2","3","4","5","6","7","8","9"};
	String mon[]={"Sep","Oct"};
	String year[]={"1972","1973"};
	String pl[]={"Java","C","C++"};
	ButtonGroup bg;
	public void init()
	{
		try
		{
		SwingUtilities.invokeAndWait(
		new Runnable()
		{
			public void run()
			{
				makeGUI();
			}
		}
		);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
private void makeGUI()
	{
	setLayout(new FlowLayout());
jl10=new JLabel("You selected");
	jl1=new JLabel("Resume");
	add(jl1);
	jl2=new JLabel("Personal Information");
	jl3=new JLabel("Name:");
	jtf1=new JTextField("HJR",10);
	add(jl2);
	add(jl3);
	add(jtf1);
jtf1.addActionListener(
new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				jl10.setText("Name:"+jtf1.getText());
			}
		}
);

	jl4=new JLabel("DOB: Day");
	jcb1=new JComboBox(day);
	jl5=new JLabel("Month");
	jcb2=new JComboBox(mon);
	jl6=new JLabel("Year");
	jcb3=new JComboBox(year);
	add(jl4);
	add(jcb1);
	add(jl5);
	add(jcb2);
	add(jl6);
	add(jcb3);
	jcb1.addActionListener(
	new ActionListener()
		{
		public void actionPerformed(ActionEvent ae)
			{
				String s=(String)jcb1.getSelectedItem();
				jl10.setText("Day: "+s);
			}
		}
	);

	jcb2.addActionListener(
	new ActionListener()
		{
		public void actionPerformed(ActionEvent ae)
			{
				String s=(String)jcb2.getSelectedItem();
				jl10.setText("Mon: "+s);
			}
		}
	);
jcb3.addActionListener(
	new ActionListener()
		{
		public void actionPerformed(ActionEvent ae)
			{
				String s=(String)jcb3.getSelectedItem();
				jl10.setText("Year: "+s);
			}
		}
	);

	jl7=new JLabel("Gender");
	jrb1=new JRadioButton("Male",true);
	jrb2=new JRadioButton("Female");
	bg=new ButtonGroup();
	add(jl7);
	add(jrb1);
	add(jrb2);
	bg.add(jrb1);
	bg.add(jrb2);

	jrb1.addActionListener(
		new ActionListener()
		{
		public void actionPerformed(ActionEvent ae)
			{
			jl10.setText("Gender:"+ae.getActionCommand());
			}
		}
		);

		jrb2.addActionListener(
		new ActionListener()
		{
		public void actionPerformed(ActionEvent ae)
			{
			jl10.setText("Gender:"+ae.getActionCommand());
			}
		}
		);
	jl8=new JLabel("Educational Qualification");
	jc1=new JCheckBox("SSLC");
	jc2=new JCheckBox("PUC");
	jc3=new JCheckBox("BE");
	jc4=new JCheckBox("PhD");
	add(jl8);
	add(jc1);
	add(jc2);
	add(jc3);
	add(jc4);
	jc1.addItemListener(this);
		jc2.addItemListener(this);
			jc3.addItemListener(this);
				jc4.addItemListener(this);

jl9=new JLabel("Programming Language Knowledge");
jlst1=new JList(pl);
add(jl9);
add(jlst1);
jlst1.addListSelectionListener(
new ListSelectionListener()
		{
	public void valueChanged(ListSelectionEvent lse)
			{
				int idx=jlst1.getSelectedIndex();
				if(idx!=-1)
					jl10.setText("Programming Language:"+pl[idx]);
				else
					jl10.setText("Select city");
			}
		}
);
jb1=new JButton("OK");
jb2=new JButton("Cancel");
add(jb1);
add(jb2);
jb1.addActionListener(
new ActionListener()
		{
	public void actionPerformed(ActionEvent ae)
			{
				jl10.setText("Clicked "+ae.getActionCommand()+" Button");
			}
		}
);

jb2.addActionListener(
new ActionListener()
		{
	public void actionPerformed(ActionEvent ae)
			{
				jl10.setText("Clicked "+ae.getActionCommand()+" Button");
			}
		}
);

add(jl10);

	}

public void itemStateChanged(ItemEvent ie)
	{
	JCheckBox jcbx=(JCheckBox)ie.getItem();
	if(jcbx.isSelected())
		jl10.setText(jcbx.getText()+" is selected");
	else
		jl10.setText(jcbx.getText()+" is cleared");
	}
}
