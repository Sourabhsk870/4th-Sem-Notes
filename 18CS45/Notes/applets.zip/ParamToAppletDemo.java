import java.awt.*;
import java.applet.*;
/*
<applet codebase="f:\hjrjava\Applets" code="ParamToAppletDemo" width="500" height="500">
<param name=one value=10>
<param name=two value=20>
<param name=three value=30>

</applet>
*/

public class  ParamToAppletDemo extends Applet
{
	int big;
	int a;
	int b;
	int c;
	public void start()
	{
		a=Integer.parseInt(getParameter("one"));
		b=Integer.parseInt(getParameter("two"));
		c=Integer.parseInt(getParameter("three"));

		big=(a>b)?((a>c)?a:c): (b>c)?b:c;
	}
	public void paint(Graphics g)
	{
		g.drawString("Biggest of "+a+","+b+","+c+":"+big,40,50);
	}
}
