import java.awt.*;
import java.applet.*;
/*
<applet code="AppletBannerDemo" width="500" height="500"></applet>
*/
public class AppletBannerDemo extends Applet implements Runnable
{
	String msg="Welcome to KSIT";
	boolean stopFlag;

	Thread t=null;

	public void init()
	{
		setForeground(Color.white);
		setBackground(Color.blue);
	}

	public void start()
	{
		t=new Thread(this);
		stopFlag=false;
		t.start();
	}

	public void run()
	{
		char ch;
		for(;;)
		{
			
			try
			{
				repaint();
				Thread.sleep(250);
				ch=msg.charAt(0);
				msg=msg.substring(1,msg.length());
				msg+=ch;

				if(stopFlag) break;
			}
			catch (InterruptedException e)
			{
				System.out.println(e);
			}
		}
	}

	public void stop()
	{
		t=null;
		stopFlag=true;
	}

	public void paint(Graphics g)
	{
		g.drawString(msg,50,50);
	}
}
