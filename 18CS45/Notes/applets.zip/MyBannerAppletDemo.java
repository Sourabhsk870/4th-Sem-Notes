import java.awt.*;
import java.applet.*;
/*
<applet code="MyBannerAppletDemo" width="500" height="500"></applet>
*/

public class MyBannerAppletDemo extends Applet implements Runnable 
{
	String msg;
	boolean setFlag;
Thread t=null;
	public void init()
	{
		setForeground(Color.white);
		setBackground(Color.blue);
	}

	public void start()
	{
		setFlag=false;
		msg="WELCOME TO KSIT ";
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		char ch;
		try
		{
			for(;;)
			{
				repaint();
				Thread.sleep(500);
				ch=msg.charAt(0);
				msg=msg.substring(1,msg.length());
				msg+=ch;

				if(setFlag) break;
			}
		}
		catch (InterruptedException e)
		{
			System.out.println(e);
		}
		
	}
	public void stop()
	{
		t=null;
		stopFlag=true;
	}

	public void paint(Graphics g)
	{
		g.drawString(msg,200,250);
		showStatus("Applet developed by HJR");
	}
}
