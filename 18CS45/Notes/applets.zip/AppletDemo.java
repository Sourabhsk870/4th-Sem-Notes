import java.awt.*;

import java.applet.*;

/*

<applet code="AppletDemo" width="500" height="500"></applet>
*/
public class  AppletDemo extends Applet
{
	String  msg="";
	public void init()
	{
		System.out.println("init");
	setBackground(Color.blue);
	setForeground(Color.white);
	
		msg+="inside init()---";
	}
	public void start()
	{
		System.out.println("Start");
	
		msg+="inside start()----";
	}

	public void stop()
	{
		System.out.println("Stop");
	}
	public void destroy()
	{
		System.out.println("Destroy");
	}

	public void paint(Graphics g)
	{
		System.out.println("paint");
		msg+="inside paint().";
		g.drawString(msg,50,50);
	}
	
}
