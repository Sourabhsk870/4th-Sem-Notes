 import java.awt.*;
import java.applet.*;
import java.net.*;
/*
<applet code="AppContxt" width="500" height="500"></applet>
*/
public class AppContxt extends Applet
{
	String msg;
	public void paint(Graphics g) 
	{
      AppletContext ac=getAppletContext();
	  URL url=getCodeBase();
		g.drawString(url.toString(),100,100);
	  try
	  {
		ac.showDocument(new URL(url+"Test.txt"));
	  }
	  catch (MalformedURLException e)
	  {
		  showStatus("URL not found");
	  }
	}
}
 

	
