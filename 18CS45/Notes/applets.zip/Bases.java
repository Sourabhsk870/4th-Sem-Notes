
import java.awt.*;
import java.applet.*;
import java.net.*;
/*
<applet code="Bases" width="500" height="500"></applet>
*/
public class Bases extends Applet
{
	String msg;
	public void paint(Graphics g) 
	{
       URL url=getCodeBase();

	   msg="Code Base:"+url.toString();

	   g.drawString(msg,40,50);

	   url=getDocumentBase();
	   
		msg="Document Base:"+url.toString();

	   g.drawString(msg,50,70);
	}
}
